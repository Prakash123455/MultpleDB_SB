package com.example.demo.dbconfig;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "studentEntityManagerFactory",transactionManagerRef = "studentTransactionManager")
public class StudentDBConfig {
	
	@Bean(name="studentDatasource")
	@ConfigurationProperties(prefix = "spring.student.datasource")
	public DataSource dataSource()
	{
		return DataSourceBuilder.create().build();
	}
	
	@Bean(name="studentEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean EntityManagerFactoryBean( EntityManagerFactoryBuilder builder, @Qualifier("studentDatasource") DataSource datasource1 )
	{
		Map m= new HashMap();
		m.put("hibernate.hbm2ddl.auto", "update");
		m.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		return builder.dataSource(datasource1).properties(m).packages("com.example.demo.entity").persistenceUnit("Students").build();
	}
	
	@Bean(name="studentTransactionManager")
	public PlatformTransactionManager TransactionManagerBean(@Qualifier("studentEntityManagerFactory") EntityManagerFactory entityManagerFactory)
	{
		return new JpaTransactionManager(entityManagerFactory);
		
	}

}
