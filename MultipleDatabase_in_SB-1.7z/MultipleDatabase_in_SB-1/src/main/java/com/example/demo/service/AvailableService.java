package com.example.demo.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.demo.entity.Employee;
import com.example.demo.entity.Students;

public interface AvailableService {

	public List<Students> getAllStudentDetails();

	public List<Employee> getAllEmployeeDetails();
	
}
