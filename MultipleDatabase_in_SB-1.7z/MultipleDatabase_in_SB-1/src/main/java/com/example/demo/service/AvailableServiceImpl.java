package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.dao.StudentDao;
import com.example.demo.entity.Employee;
import com.example.demo.entity.Students;

@Service
@Transactional
public class AvailableServiceImpl implements AvailableService {
	
	@Autowired
	EmployeeDao empd;
	@Autowired
	StudentDao std;

	@Override
	public List<Students> getAllStudentDetails() {
		return  std.findAll();
	}

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return  empd.findAll();
	}

}
