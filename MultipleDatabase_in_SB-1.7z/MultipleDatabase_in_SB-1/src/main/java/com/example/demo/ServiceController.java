package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.entity.Students;
import com.example.demo.service.AvailableService;


@RestController
public class ServiceController {
	
	@Autowired
	AvailableService abs;
	
	@GetMapping("/student")
	public List<Students> getAllStudent()
	{
		return abs.getAllStudentDetails();
	}
	@GetMapping("/employee")
	public List<Employee> getAllEmployee()
	{
		return  abs.getAllEmployeeDetails();
	}

}
